g++ algorithms.cc algtest.cpp -std=c++11 -o algtest
./algtest
